As part of my solution I have used ES6 standards.
Also react hooks and prop types.


As I hadn't design that's why I could't take margins and paddings and I think there is some difference with my markup and your pictures.
Hope you will not take it so serious))

It tooks 6.5 hours to complete the task.

Thank you for task))