import React from 'react';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import Content from './components/content/Content';
import Programs from './components/programs/Programs';
import Header from "./components/header/Header";
import Footer from "./components/footer/Footer";
import './App.css';

function App() {
    return (
        <>
            <Header/>
            <BrowserRouter>
                <Routes>
                    <Route path='/' element={<Content/>} exact/>
                    <Route path='/series' element={<Programs/>}/>
                    <Route path='/movie' element={<Programs/>}/>
                </Routes>
            </BrowserRouter>
            <Footer/>
        </>
    );
}

export default App;
