const CONSTANTS = {
    fetchURL: './json/sample.json',
    posterArt: 'Poster Art',
    itemCount: 21
} ;

export default CONSTANTS;