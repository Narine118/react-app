import React from 'react';
import {Link} from 'react-router-dom';
import SubHeader from './../subHeader/SubHeader';
import './Content.css';

const popularTitles = [
    {
        name: 'Series',
        title: 'Popular series',
        pathname: '/series'
    }, {
        name: 'Movies',
        title: 'Popular Movies',
        pathname: '/movie'
    },

];


const Content = () => {

    {
        return (
            <>
                <SubHeader title="Popular Titles"/>
                <div className="content_wrapper">
                    <div className="container">
                        <div className="titles_wrapper">
                            {popularTitles.map((el, index) => {
                                return (
                                    <div key={index}>
                                        <div className="titles_item">
                                            <Link to={el.pathname}>
                                                <span>{el.name}</span>
                                            </Link>
                                        </div>
                                        <p className="titles_text">{el.title}</p>
                                    </div>
                                )
                            })
                            }
                        </div>
                    </div>
                </div>
            </>
        )
    }
};

export default Content;