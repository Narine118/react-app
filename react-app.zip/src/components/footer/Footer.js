import './Footer.css'
import {ReactComponent as InstagramIcon} from '../../assets/icons/instagram.svg';
import {ReactComponent as FacebookIcon} from '../../assets/icons/facebook.svg';
import {ReactComponent as TwitterIcon} from '../../assets/icons/twitter.svg';
import {ReactComponent as AppStoreIcon} from '../../assets/icons/app-store.svg';
import {ReactComponent as PlayStoreIcon} from '../../assets/icons/play-store.svg';

const Footer = () => {
    return (
        <div className="footer_wrapper">
            <div className="container">
                <footer>
                    <ul className="footer_menu">
                        <li className="footer_menu_item">
                            <a href="/" className="footer_menu_link">Home</a>
                        </li>
                        <li className="footer_menu_item">
                            <a href="/" className="footer_menu_link">Terms and Conditions</a>
                        </li>
                        <li className="footer_menu_item">
                            <a href="/" className="footer_menu_link">Privacy Policy</a>
                        </li>
                        <li className="footer_menu_item">
                            <a href="/" className="footer_menu_link">Collection Statement</a>
                        </li>
                        <li className="footer_menu_item">
                            <a href="/" className="footer_menu_link">Help</a>
                        </li>
                        <li className="footer_menu_item">
                            <a href="/" className="footer_menu_link">Manage Account</a>
                        </li>
                    </ul>
                    <p className="footer_menu_copyright">Copyright © 2016 DEMO Streaming. All Rights Reserved.</p>
                </footer>
                <div className="bottom_footer_wrapper">
                    <ul className="footer-social_icons">
                        <li className="footer_social_link">
                            <a href="/">
                                <FacebookIcon/>
                            </a>
                        </li>
                        <li className="footer_social_link">
                            <a href="/">
                                <TwitterIcon/>
                            </a>
                        </li>
                        <li className="footer_social_link">
                            <a href="/">
                                <InstagramIcon/>
                            </a>
                        </li>
                    </ul>
                    <ul className="footer_app_img">
                        <li className="footer_app_img_link">
                            <a href="/">
                               <AppStoreIcon/>
                            </a>
                        </li>
                        <li className="footer_app_img_link">
                            <a href="/">
                                <PlayStoreIcon/>
                            </a>
                        </li>
                        <li className="footer_app_img_link">
                            <a href="/">
                               <PlayStoreIcon/>
                            </a>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    )

};

export default Footer;