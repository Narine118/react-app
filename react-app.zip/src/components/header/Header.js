import './Header.css'

const Header = () => {
    return (
        <div className="header_wrapper">
            <div className="container">
                <header className="header">
                    <h1 className="header_text">DEMO Streaming</h1>
                    <div className="header_buttons">
                        <a className="header_logIn" href="/"> Log in</a>
                        <a className="button" href="/">Start your free trial</a>
                    </div>
                </header>
            </div>
        </div>
    )

}

export default Header;