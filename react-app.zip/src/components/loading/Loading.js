

const  Loading = () => {
     return <div className="container content_wrapper">Loading ...</div>
}

export default Loading;