import {useEffect, useState} from "react";
import Loading from '../loading/Loading';
import CONSTANTS from './../constants';
import SubHeader from './../subHeader/SubHeader';
import './Programs.css';

const Programs = () => {

    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const getData = () => {
        fetch(`${CONSTANTS.fetchURL}`
            , {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            }
        )
            .then(function (response) {
                return response.json();
            }).then(data => {

            setTimeout(() => {
                setData(data.entries);
            }, 500);

        }).catch(() => {
            setError('Oops, something went wrong;')
        });

    };

    useEffect(() => {
        getData();
    }, []);


    useEffect(() => {
        !data.length ? setLoading(true) : setLoading(false);
    }, [data]);


    //get program type from url
    const url = window.location.href.split('/');
    const programTypeUrl = url[url.length - 1];


    const filteredData = () => data.filter((el) => el.releaseYear >= 2010 && el.programType === programTypeUrl);
    const sortedData = () => filteredData().sort((a, b) => a.title.localeCompare(b.title));
    const dataCount = () => sortedData().splice(0, CONSTANTS.itemCount);
    const newData = dataCount();

    const render = () => {
        if (!loading && !error) {
            return (
                <div className="container">
                    <div className="programs_wrapper">
                        {newData.map((el, index) => {
                            return (
                                <div key={index} className="programs_item">
                                    <div>
                                        <img src={el.images[CONSTANTS.posterArt].url} alt={el.title}/>
                                    </div>
                                    <p>{el.title}</p>
                                </div>
                            )
                        })
                        }
                    </div>
                </div>
            )
        } else if (loading) {
            return <Loading/>
        } else {
            return <div className="container content_wrapper">{error}</div>
        }

    };

    return <><SubHeader title={programTypeUrl === 'series' ? 'Popular Series' : 'Popular Movies'}/>{render()}</>;
};


export default Programs