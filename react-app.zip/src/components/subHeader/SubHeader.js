import PropTypes from 'prop-types';
import './SubHeader.css'

const SubHeader = (props) => {
    const {title} = props;
    return (
        <div className="subheader_wrapper">
            <div className="container">
                <div  className="subheader_text">{title}</div>
            </div>
        </div>
    )

};
SubHeader.propTypes = {
    title: PropTypes.string,
};
SubHeader.defaultProps = {
    title: '',
};
export default SubHeader;